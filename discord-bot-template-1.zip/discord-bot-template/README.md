# Discord Bot Template

## Instalação

```bash
npm install
```

## Configurar

Renomeie `.env.example` para `.env`

Depois coloque:

```env
TOKEN=SEU_TOKEN
CLIENT_ID=SEU_CLIENT_ID
```

## Rodar

```bash
npm start
```

---

# Como colocar online

## Railway
1. Crie conta
2. Suba os arquivos
3. Configure variáveis `.env`
4. Deploy

Site:
https://railway.app

## Render
https://render.com

## VPS Linux

Instale:
- Node.js
- PM2

Rodar:

```bash
npm install
pm2 start index.js
```

Salvar PM2:

```bash
pm2 save
```