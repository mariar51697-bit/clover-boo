require('dotenv').config();

const {
  Client,
  GatewayIntentBits,
  Partials,
  Events,
  EmbedBuilder
} = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

client.once(Events.ClientReady, () => {
  console.log(`Bot online: ${client.user.tag}`);
});

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  if (message.content === '!ping') {
    return message.reply('Pong!');
  }

  if (message.content === '!server') {
    const embed = new EmbedBuilder()
      .setTitle('Informações do servidor')
      .addFields(
        { name: 'Nome', value: message.guild.name },
        { name: 'Membros', value: `${message.guild.memberCount}` }
      )
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  }

  if (message.content.startsWith('!clear')) {
    if (!message.member.permissions.has('ManageMessages')) {
      return message.reply('Sem permissão.');
    }

    const args = message.content.split(' ');
    const amount = parseInt(args[1]);

    if (!amount || amount < 1 || amount > 100) {
      return message.reply('Escolha entre 1 e 100.');
    }

    await message.channel.bulkDelete(amount, true);
    message.channel.send(`Apaguei ${amount} mensagens.`);
  }
});

client.login(process.env.TOKEN);