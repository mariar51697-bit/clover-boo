# Discord Bot Render Ready

## Como subir no Render

1. Crie repositório GitHub
2. Envie os arquivos
3. Vá no Render
4. New +
5. Background Worker
6. Connect Repository
7. Adicione variável:

TOKEN=SEU_TOKEN

8. Deploy

---

# Rodar local

npm install
npm start