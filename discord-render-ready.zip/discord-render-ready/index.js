require('dotenv').config();

const {
  Client,
  GatewayIntentBits,
  Events,
  EmbedBuilder
} = require('discord.js');

if (!process.env.TOKEN) {
  console.error('TOKEN não encontrada.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

client.once(Events.ClientReady, () => {
  console.log(`Bot online: ${client.user.tag}`);
});

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  if (message.content === '!ping') {
    return message.reply('Pong!');
  }

  if (message.content === '!help') {
    const embed = new EmbedBuilder()
      .setTitle('Comandos')
      .setDescription('!ping\n!help\n!server')
      .setTimestamp();

    return message.reply({ embeds: [embed] });
  }

  if (message.content === '!server') {
    const embed = new EmbedBuilder()
      .setTitle('Servidor')
      .addFields(
        { name: 'Nome', value: message.guild.name },
        { name: 'Membros', value: `${message.guild.memberCount}` }
      );

    return message.reply({ embeds: [embed] });
  }
});

client.login(process.env.TOKEN);